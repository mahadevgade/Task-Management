package com.inventonus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagementBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
