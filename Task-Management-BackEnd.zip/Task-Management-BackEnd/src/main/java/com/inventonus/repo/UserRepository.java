package com.inventonus.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inventonus.entity.UserEntity;


public interface UserRepository extends JpaRepository<UserEntity, Long>{

	// select * from user_entity where userName=:userName
	public UserEntity findByUserName(String userName);
}
