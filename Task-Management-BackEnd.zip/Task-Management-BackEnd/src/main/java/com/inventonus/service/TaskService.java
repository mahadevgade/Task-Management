package com.inventonus.service;

import java.util.List;

import com.inventonus.dto.TaskDto;
import com.inventonus.dto.UpdateTaskForm;
import com.inventonus.entity.Task;

public interface TaskService {
	
	// create Tasks
	public boolean createTask(TaskDto taskDto);
	
	// get All the Task
	public List<TaskDto> getAllTasks();
	
	// update Task
	public Task updateTask(UpdateTaskForm taskForm, Long taskId);
	
	// delete Task
	public void deleteTask(Long taskId);

}
