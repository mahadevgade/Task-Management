import {
  MatDivider,
  MatDividerModule
} from "./chunk-DIL36TIY.js";
import "./chunk-QEGPYYQA.js";
import "./chunk-DAQRDSN2.js";
import "./chunk-UDNQAWME.js";
import "./chunk-M3HR6BUY.js";
import "./chunk-JALJBC6N.js";
import "./chunk-GZSH2FAC.js";
import "./chunk-6KMWFVLN.js";
import "./chunk-EOH7TK5Q.js";
export {
  MatDivider,
  MatDividerModule
};
