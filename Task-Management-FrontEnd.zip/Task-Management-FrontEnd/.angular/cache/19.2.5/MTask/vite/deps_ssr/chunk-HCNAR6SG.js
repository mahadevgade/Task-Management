import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs,
  require_operators
} from "./chunk-4RDLTH23.js";
import {
  __toESM
} from "./chunk-YHCV7DAQ.js";

// node_modules/@angular/cdk/fesm2022/scrolling.mjs
var import_rxjs = __toESM(require_cjs(), 1);
var import_operators = __toESM(require_operators(), 1);
//# sourceMappingURL=chunk-HCNAR6SG.js.map
