import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-YBODC4LN.js";
import "./chunk-7LEHMZOP.js";
import "./chunk-UYDFKG6B.js";
import "./chunk-HJTKKQ3X.js";
import "./chunk-UF743SJM.js";
import "./chunk-QZ3YYIM6.js";
import "./chunk-7UXD3U5R.js";
import "./chunk-IXIDN2OZ.js";
import "./chunk-4RDLTH23.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
