export interface RegisterPayload {
     userName : string;
     userPassword : string;
}
