export interface TaskDto { 
    taskTitle:string,
    taskDescription:string
}
