export interface LoginPayload {

    userName: string;
    userPassword: string;
}
